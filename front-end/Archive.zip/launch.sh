. venv/bin/activate
. ./.env_dev
python app.py
