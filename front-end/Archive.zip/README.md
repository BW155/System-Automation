Dit is het gedeelte voor de front-end van het project. Deze is geschreven in Python3.

# How to use
Om dit op te starten doe je `sh init.sh` en doe je `sh launch.sh`, that's it.
